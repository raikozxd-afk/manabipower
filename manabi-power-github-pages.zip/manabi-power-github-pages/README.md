# Manabí Power 2026 - Mesa de Control Web

Sistema oficial de registro, pesaje y clasificación para el Campeonato Manabí Power 2026 (IFBB - Manta, Ecuador).

## Cómo subirlo GRATIS usando GitHub Pages (Paso a paso)

### Paso 1: Crear cuenta en GitHub (si no tienes)

1. Entra a [https://github.com](https://github.com)
2. Haz clic en **Sign up** y crea una cuenta gratis.

### Paso 2: Crear un nuevo repositorio

1. Una vez logueado, haz clic en el botón **"+"** (arriba a la derecha) → **New repository**.
2. En **Repository name** escribe: `manabi-power`
3. Deja todo lo demás por defecto.
4. Haz clic en **Create repository**.

### Paso 3: Subir el archivo

1. En la página del repositorio que acabas de crear, haz clic en **uploading an existing file**.
2. Arrastra el archivo **`index.html`** que está en esta carpeta y suéltalo.
3. En el mensaje de commit escribe: `Subir Manabí Power Web`
4. Haz clic en **Commit changes**.

### Paso 4: Activar GitHub Pages

1. En tu repositorio, ve a la pestaña **Settings** (arriba).
2. En el menú de la izquierda, haz clic en **Pages**.
3. En **Source**, selecciona **Deploy from a branch**.
4. En **Branch**, selecciona `main` y carpeta `/ (root)`.
5. Haz clic en **Save**.

### Paso 5: Esperar y acceder

- Espera entre **30 segundos y 2 minutos**.
- Actualiza la página.
- Verás un enlace que dice:  
  **Your site is published at** `https://tuusuario.github.io/manabi-power`

¡Ese es tu dominio gratis!

---

## Ejemplo de enlace final:

`https://tuusuario.github.io/manabi-power`

---

## Notas importantes

- La primera vez puede tardar un poco en aparecer.
- Cada vez que quieras actualizar la página, solo subes el nuevo `index.html` al repositorio.
- La sincronización con la nube (kvdb.io) funciona normalmente.

---

¿Necesitas ayuda con algún paso? Dime en qué parte te atascaste.